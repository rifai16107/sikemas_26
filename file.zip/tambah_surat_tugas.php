<?php
    //cek session
    if(empty($_SESSION['admin'])){
        $_SESSION['err'] = '<center>Anda harus login terlebih dahulu!</center>';
        header("Location: ./");
        die();
    } else {

        if(isset($_REQUEST['submit'])){

            //validasi form kosong
            if($_REQUEST['no_agenda'] == "" || $_REQUEST['no_surtug'] == "" || $_REQUEST['nama_peg'] == "" || $_REQUEST['nip'] == ""
                || $_REQUEST['pangkat'] == "" || $_REQUEST['jabatan'] == "" || $_REQUEST['tujuan_tgs'] == "" || $_REQUEST['tgl_mulai'] == ""  || $_REQUEST['tgl_selesai'] == "" || $_REQUEST['beban_ang'] == "" || $_REQUEST['kode'] == ""){
                $_SESSION['errEmpty'] = 'ERROR! Semua form wajib diisi';
                echo '<script language="javascript">window.history.back();</script>';
            } else {

                $no_agenda = $_REQUEST['no_agenda'];
                $no_surtug = $_REQUEST['no_surtug'];
                $nama_peg = $_REQUEST['nama_peg'];
                $nip = $_REQUEST['nip'];
                $pangkat = $_REQUEST['pangkat'];
                $jabatan = $_REQUEST['jabatan'];
                $tujuan_tgs = $_REQUEST['tujuan_tgs'];
                $tgl_mulai = $_REQUEST['tgl_mulai'];
                $tgl_selesai = $_REQUEST['tgl_selesai'];
                $beban_ang = $_REQUEST['beban_ang'];
                $kode = substr($_REQUEST['kode'],0,30);
                $nkode = trim($kode);
                $id_user = $_SESSION['id_user'];

                $nosu_lengkap=$no_surtug."/".$nkode."/".date('n')."/".date('Y');

                //validasi input data
                if(!preg_match("/^[0-9]*$/", $no_agenda)){
                    $_SESSION['no_agenda'] = 'Form Nomor Agenda harus diisi angka!';
                    echo '<script language="javascript">window.history.back();</script>';
                } else {
                   if(!preg_match("/^[a-zA-Z0-9., ]*$/", $nkode)){
                      $_SESSION['kode'] = 'Form Kode Klasifikasi hanya boleh mengandung karakter huruf, angka, spasi, titik(.) dan koma(,)';
                      echo '<script language="javascript">window.history.back();</script>';
                   } else { 
                    if(!preg_match("/^[0-9]*$/", $no_surtug)){
                        $_SESSION['no_surtugk'] = 'Form No Surat hanya boleh mengandung karakter huruf, angka, spasi, titik(.), minus(-) dan garis miring(/)';
                        echo '<script language="javascript">window.history.back();</script>';
                    } else {

                        if(!preg_match("/^[a-zA-Z0-9.,() \/ -]*$/", $nama_peg)){
                            $_SESSION['nama_pegk'] = 'Form Nama Pegawai hanya boleh mengandung karakter huruf, angka, spasi, titik(.), koma(,), minus(-),kurung() dan garis miring(/)';
                            echo '<script language="javascript">window.history.back();</script>';
                        } else {

                            if(!preg_match("/^[0-9]*$/", $nip)){
                                $_SESSION['nipk'] = 'Form NIP hanya boleh mengandung karakter huruf, angka, spasi, titik(.), minus(-) dan garis miring(/)';
                                echo '<script language="javascript">window.history.back();</script>';
                            } else {

                                if(!preg_match("/^[a-zA-Z0-9.,() \/ -]*$/", $pangkat)){
                                    $_SESSION['pangkatk'] = 'Form Pangkat hanya boleh mengandung karakter huruf, angka, spasi, titik(.), koma(,), minus(-), kurung() dan garis miring(/)';
                                    echo '<script language="javascript">window.history.back();</script>';
                                } else {

                                    if(!preg_match("/^[a-zA-Z0-9.,() \/ -]*$/", $jabatan)){
                                        $_SESSION['jabatank'] = 'Form Jabatan hanya boleh mengandung karakter huruf, angka, spasi, titik(.), koma(,), minus(-), kurung() dan garis miring(/)';
                                        echo '<script language="javascript">window.history.back();</script>';
                                    } else {
                                        if(!preg_match("/^[a-zA-Z0-9., -]*$/", $tujuan_tgs)){
                                          $_SESSION['tujuan_tgsk'] = 'Form Tujuan Tugas hanya boleh mengandung karakter huruf, angka, spasi, titik(.) dan koma(,) dan minus (-)';
                                           echo '<script language="javascript">window.history.back();</script>';
                                        } else {
                                          if(!preg_match("/^[0-9.-]*$/", $tgl_mulai)){
                                            $_SESSION['tgl_mulai'] = 'Form Tanggal hanya boleh mengandung angka dan minus(-)';
                                            echo '<script language="javascript">window.history.back();</script>';
                                          } else {
                                               if(!preg_match("/^[0-9.-]*$/", $tgl_selesai)){
                                                $_SESSION['tgl_selesai'] = 'Form Tanggal hanya boleh mengandung angka dan minus(-)';
                                                 echo '<script language="javascript">window.history.back();</script>';
                                              } else {
                                            if(!preg_match("/^[a-zA-Z0-9.,()\/ -]*$/", $beban_ang)){
                                                $_SESSION['beban_ang'] = 'Form beban anggaran hanya boleh mengandung karakter huruf, angka, spasi, titik(.), koma(,), minus(-), garis miring(/), dan kurung()';
                                                echo '<script language="javascript">window.history.back();</script>';
                                            } else {

                                                $cek = mysqli_query($config, "SELECT * FROM tbl_surat_tugas WHERE no_surat='$no_surat'");
                                                $result = mysqli_num_rows($cek);

                                                if($result > 0){
                                                    $_SESSION['errDup'] = 'Nomor Surat sudah terpakai, gunakan yang lain!';
                                                    echo '<script language="javascript">window.history.back();</script>';
                                                } else {

                                                    $ekstensi = array('jpg','png','jpeg','doc','docx','pdf');
                                                    $file = $_FILES['file']['name'];
                                                    $x = explode('.', $file);
                                                    $eks = strtolower(end($x));
                                                    $ukuran = $_FILES['file']['size'];
                                                    $target_dir = "upload/surat_tugas/";

                                                    if (! is_dir($target_dir)) {
                                                        mkdir($target_dir, 0755, true);
                                                    }

                                                    //jika form file tidak kosong akan mengeksekusi script dibawah ini
                                                    if($file != ""){

                                                        $rand = rand(1,10000);
                                                        $nfile = $rand."-".$file;

                                                        //validasi file
                                                        if(in_array($eks, $ekstensi) == true){
                                                            if($ukuran < 2500000){

                                                                move_uploaded_file($_FILES['file']['tmp_name'], $target_dir.$nfile);

                                                                $query = mysqli_query($config, "INSERT INTO tbl_surat_tugas(no_agenda,no_surtug,nosu_lengkap,nama_peg,nip,pangkat,jabatan,tujuan_tgs,tgl_mulai, tgl_selesai,file,beban_ang,kode,id_user)
                                                            VALUES('$no_agenda','$no_surtug','$nosu_lengkap','$nama_peg','$nip','$pangkat','$jabatan','$tujuan_tgs','$tgl_mulai','$tgl_selesai','$nfile','$beban_ang','$nkode','$id_user')");

                                                                if($query == true){
                                                                    $_SESSION['succAdd'] = 'SUKSES! Data berhasil ditambahkan';
                                                                    header("Location: ./admin.php?page=tst");
                                                                    die();
                                                                } else {
                                                                    $_SESSION['errQ'] = 'ERROR! Ada masalah dengan query';
                                                                    echo '<script language="javascript">window.history.back();</script>';
                                                                }
                                                            } else {
                                                                $_SESSION['errSize'] = 'Ukuran file yang diupload terlalu besar!';
                                                                echo '<script language="javascript">window.history.back();</script>';
                                                            }
                                                        } else {
                                                            $_SESSION['errFormat'] = 'Format file yang diperbolehkan hanya *.JPG, *.PNG, *.DOC, *.DOCX atau *.PDF!';
                                                            echo '<script language="javascript">window.history.back();</script>';
                                                        }
                                                    } else {

                                                        //jika form file kosong akan mengeksekusi script dibawah ini
                                                        $query = mysqli_query($config, "INSERT INTO tbl_surat_tugas(no_agenda,no_surtug,nosu_lengkap,nama_peg,nip,pangkat,jabatan,tujuan_tgs,tgl_mulai, tgl_selesai,file,beban_ang,kode,id_user)
                                                            VALUES('$no_agenda','$no_surtug','$nosu_lengkap','$nama_peg','$nip','$pangkat','$jabatan','$tujuan_tgs','$tgl_mulai','$tgl_selesai','$nfile','$beban_ang','$nkode','$id_user')");

                                                        if($query == true){
                                                            $_SESSION['succAdd'] = 'SUKSES! Data berhasil ditambahkan';
                                                            header("Location: ./admin.php?page=tst");
                                                            die();
                                                        } else {
                                                            $_SESSION['errQ'] = 'ERROR! Ada masalah dengan query';
                                                            echo '<script language="javascript">window.history.back();</script>';
                                                        }
                                                    }
                                                  }  
                                                }
                                              }   
                                            }
                                          }  
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {?>

            <!-- Row Start -->
            <div class="row">
                <!-- Secondary Nav START -->
                <div class="col s12">
                    <nav class="secondary-nav">
                        <div class="nav-wrapper blue darken-1">
                            <ul class="left">
                                <li class="waves-effect waves-light"><a href="?page=tst&act=add" class="judul"><i class="material-icons">mail</i> Tambah Data Surat Tugas</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
                <!-- Secondary Nav END -->
            </div>
            <!-- Row END -->

            <?php
                if(isset($_SESSION['errQ'])){
                    $errQ = $_SESSION['errQ'];
                    echo '<div id="alert-message" class="row">
                            <div class="col m12">
                                <div class="card red lighten-5">
                                    <div class="card-content notif">
                                        <span class="card-title red-text"><i class="material-icons md-36">clear</i> '.$errQ.'</span>
                                    </div>
                                </div>
                            </div>
                        </div>';
                    unset($_SESSION['errQ']);
                }
                if(isset($_SESSION['errEmpty'])){
                    $errEmpty = $_SESSION['errEmpty'];
                    echo '<div id="alert-message" class="row">
                            <div class="col m12">
                                <div class="card red lighten-5">
                                    <div class="card-content notif">
                                        <span class="card-title red-text"><i class="material-icons md-36">clear</i> '.$errEmpty.'</span>
                                    </div>
                                </div>
                            </div>
                        </div>';
                    unset($_SESSION['errEmpty']);
                }
            ?>

            <!-- Row form Start -->
            <div class="row jarak-form">

                <!-- Form START -->
                <form class="col s12" method="POST" action="?page=tst&act=add" enctype="multipart/form-data">

                    <!-- Row in form START -->
                    <div class="row">
                        <div class="input-field col s6">
                            <i class="material-icons prefix md-prefix">looks_one</i>
                            <?php
                            echo '<input id="no_agenda" type="number" class="validate" name="no_agenda" value="';
                                $sql = mysqli_query($config, "SELECT no_agenda FROM tbl_surat_tugas");
                                $no_agenda = "1";
                                if (mysqli_num_rows($sql) == 0){
                                    echo $no_agenda;
                                }

                                $result = mysqli_num_rows($sql);
                                $counter = 0;
                                while(list($no_agenda) = mysqli_fetch_array($sql)){
                                    if (++$counter == $result) {
                                        $no_agenda++;
                                        echo $no_agenda;
                                    }
                                }
                                echo '" readonly required>';

                                if(isset($_SESSION['no_agenda'])){
                                    $no_agendak = $_SESSION['no_agendak'];
                                    echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$no_agendak.'</div>';
                                    unset($_SESSION['no_agenda']);
                                }
                            ?>
                            <label for="no_agenda">Nomor Agenda</label>
                        </div>
                        <div class="input-field col s6">
                            <i class="material-icons prefix md-prefix">looks_two</i>
                            <input id="kode" type="text" class="validate" name="kode" required>
                                <?php
                                    if(isset($_SESSION['kode'])){
                                        $kode = $_SESSION['kode'];
                                        echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$kode.'</div>';
                                        unset($_SESSION['kode']);
                                    }
                                ?>
                            <label for="kode">Kode Klasifikasi</label>
                        </div>
                        <div class="input-field col s6">
                            <i class="material-icons prefix md-prefix">storage</i>
                            <div class="input-field col s11 right">
                                <select name="nama_peg" id="nama_peg" type="text" class="browser-default validate" onchange='changeValue(this.value)' required>
                                  <option value="">-Pilih-</option>
                                 <?php 
                                 $query=mysqli_query($config, "select * from tbl_pegawai order by nama_peg asc"); 
                                 $result = mysqli_query($config, "select * from tbl_pegawai order by nama_peg asc");  
                                 $jsArray = "var prdName = new Array();\n";
                                 while ($row = mysqli_fetch_array($result)) {  
                                 echo '<option name="nama_peg"  value="' . $row['nama_peg'] . '">' . $row['nama_peg'] . '</option>';  
                                 $jsArray .= "prdName['" . $row['nama_peg'] . "'] = {nip:'" . addslashes($row['nip']) . "',pangkat:'".addslashes($row['pangkat'])."',jabatan:'".addslashes($row['jabatan'])."'};\n";
                                  }
                                  ?>
                                </select>
                                <input id="nip" type="text" class="validate" name="nip" readonly />
                                <input id="pangkat" type="text" class="validate" name="pangkat" readonly />
                                <input id="jabatan" type="text" class="validate" name="jabatan" readonly />
                            </div>    
                            <label for="nama_peg">Nama Pegawai</label>
                        </div>

                        <div class="input-field col s6">
                            <i class="material-icons prefix md-prefix">description</i>
                            <?php
                              
                                echo '<input id="no_surtug" type="text" class="validate" name="no_surtug" readonly value="';
                                $sql = mysqli_query($config, "SELECT no_surtug FROM tbl_surat_tugas order by no_surtug ASC");
                                $no_surtug = "001";
                                if (mysqli_num_rows($sql) == 0){
                                    echo $no_surtug;
                                }

                                $result = mysqli_num_rows($sql);
                                $counter = 0;
                                while(list($no_surtug) = mysqli_fetch_array($sql)){
                                    if (++$counter == $result) {
                                        $no_surtug++;
                                        $urutan=$no_surtug++;
                                        $no_surtug = sprintf("%03s", $urutan);
                                        echo $no_surtug;
                                    }
                                }
                                echo '" readonly required>';

                                if(isset($_SESSION['no_surtugk'])){
                                    $no_agendak = $_SESSION['no_surtugk'];
                                    echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$no_surtugk.'</div>';
                                    unset($_SESSION['no_surtugk']);
                                }
                                if(isset($_SESSION['errDup'])){
                                        $errDup = $_SESSION['errDup'];
                                        echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$errDup.'</div>';
                                        unset($_SESSION['errDup']);
                                }
                            ?>
                            <label for="no_surtug">Nomor Surat</label>
                        </div>

                        <div class="input-field col s6">
                            <i class="material-icons prefix md-prefix">description</i>
                             
                            <input id="tujuan_tgs" type="text" class="validate" name="tujuan_tgs" required>
                                <?php
                                    if(isset($_SESSION['tujuan_tgsk'])){
                                        $tujuan_tgsk = $_SESSION['tujuan_tgsk'];
                                        echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$tujuan_tgsk.'</div>';
                                        unset($_SESSION['tujuan_tgsk']);
                                    }
                                ?>
                           
                            <label for="tujuan_tgs">Tujuan Tugas</label>
                        </div>

                        <div class="input-field col s6">
                            <i class="material-icons prefix md-prefix">date_range</i>
                            <input id="tgl_mulai" type="text" name="tgl_mulai" class="datepicker" required>
                                <?php
                                    if(isset($_SESSION['tgl_mulai'])){
                                        $tgl_mulai = $_SESSION['tgl_mulai'];
                                        echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$tgl_mulai.'</div>';
                                        unset($_SESSION['tgl_mulai']);
                                    }
                                ?>
                            <label for="tgl_mulai">Tanggal Mulai</label>
                        </div>

                        <div class="input-field col s6">
                            <i class="material-icons prefix md-prefix">date_range</i>
                            <input id="tgl_selesai" type="text" name="tgl_selesai" class="datepicker" required>
                                <?php
                                    if(isset($_SESSION['tgl_selesai'])){
                                        $tgl_selesai = $_SESSION['tgl_selesai'];
                                        echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$tgl_selesai.'</div>';
                                        unset($_SESSION['tgl_selesai']);
                                    }
                                ?>
                            <label for="tgl_selesai">Tanggal Selesai</label>
                        </div>
                        <div class="input-field col s6">
                            <i class="material-icons prefix md-prefix">description</i>
                            <input id="beban_ang" type="text" class="validate" name="beban_ang"   required></textarea>
                                <?php
                                    if(isset($_SESSION['beban_angk'])){
                                        $beban_ang = $_SESSION['beban_angk'];
                                        echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$beban_angk.'</div>';
                                        unset($_SESSION['beban_angk']);
                                    }
                                ?>
                            <label for="beban_ang">Pembebanan</label>
                        </div>
                        
                        <div class="input-field col s6">
                            <div class="file-field input-field">
                                <div class="btn light-green darken-1">
                                    <span>File</span>
                                    <input type="file" id="file" name="file">
                                </div>
                                <div class="file-path-wrapper">
                                    <input class="file-path validate" type="text" placeholder="Upload file/scan gambar surat tugas">
                                        <?php
                                            if(isset($_SESSION['errSize'])){
                                                $errSize = $_SESSION['errSize'];
                                                echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$errSize.'</div>';
                                                unset($_SESSION['errSize']);
                                            }
                                            if(isset($_SESSION['errFormat'])){
                                                $errFormat = $_SESSION['errFormat'];
                                                echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$errFormat.'</div>';
                                                unset($_SESSION['errFormat']);
                                            }
                                        ?>
                                    <small class="red-text">*Format file yang diperbolehkan *.JPG, *.PNG, *.DOC, *.DOCX, *.PDF dan ukuran maksimal file 2 MB!</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Row in form END -->

                    <div class="row">
                        <div class="col 6">
                            <button type="submit" name="submit" class="btn-large blue waves-effect waves-light">SIMPAN <i class="material-icons">done</i></button>
                        </div>
                        <div class="col 6">
                            <a href="?page=tst" class="btn-large deep-orange waves-effect waves-light">BATAL <i class="material-icons">clear</i></a>
                        </div>
                    </div>

                </form>
                <!-- Form END -->

            </div>
            <!-- Row form END -->

<?php
        }
    }
?>
<script type="text/javascript"> 
<?php echo $jsArray; ?>
function changeValue(id){
    document.getElementById('nip').value = prdName[id].nip;
    document.getElementById('pangkat').value = prdName[id].pangkat;
    document.getElementById('jabatan').value = prdName[id].jabatan;
};
</script>