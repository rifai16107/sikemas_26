<?php
    //cek session
    if(empty($_SESSION['admin'])){
        $_SESSION['err'] = '<center>Anda harus login terlebih dahulu!</center>';
        header("Location: ./");
        die();
    } else {

        if(isset($_REQUEST['submit'])){

            //validasi form kosong
            if($_REQUEST['no_agenda'] == "" || $_REQUEST['no_surtug'] == "" || $_REQUEST['tujuan_tgs'] == "" || $_REQUEST['tgl_mulai'] == "" || $_REQUEST['tgl_selesai'] == "" || $_REQUEST['beban_ang'] == "" || $_REQUEST['kode'] == ""){
                $_SESSION['errEmpty'] = 'ERROR! Semua form wajib diisiii';
                echo '<script language="javascript">window.history.back();</script>';
            } else {

                $no_agenda = $_REQUEST['no_agenda'];
                $no_surtug = $_REQUEST['no_surtug'];
                $nama_peg = $_REQUEST['nama_peg'];
                $nip = $_REQUEST['nip'];
                $pangkat = $_REQUEST['pangkat'];
                $jabatan = $_REQUEST['jabatan'];
                $tujuan_tgs = $_REQUEST['tujuan_tgs'];
                $tgl_mulai = $_REQUEST['tgl_mulai'];
                $tgl_selesai = $_REQUEST['tgl_selesai'];
                $beban_ang = $_REQUEST['beban_ang'];
                $kode = substr($_REQUEST['kode'],0,30);
                $nkode = trim($kode);
                $id_user = $_SESSION['id_user'];

                $nosu_lengkap=$no_surtug."/".$nkode."/".date('n')."/".date('Y');

                //validasi input data
                if(!preg_match("/^[0-9]*$/", $no_agenda)){
                    $_SESSION['eno_agenda'] = 'Form Nomor Agenda harus diisi angka!';
                    echo '<script language="javascript">window.history.back();</script>';
                } else {
                   if(!preg_match("/^[a-zA-Z0-9., ]*$/", $nkode)){
                      $_SESSION['ekode'] = 'Form Kode Klasifikasi hanya boleh mengandung karakter huruf, angka, spasi, titik(.) dan koma(,)';
                      echo '<script language="javascript">window.history.back();</script>';
                   } else { 
                    if(!preg_match("/^[0-9]*$/", $no_surtug)){
                        $_SESSION['eno_surtug'] = 'Form No Surat hanya boleh mengandung karakter huruf, angka, spasi, titik(.), minus(-) dan garis miring(/)';
                        echo '<script language="javascript">window.history.back();</script>';
                    } else {

                        if(!preg_match("/^[a-zA-Z0-9.,() \/ -]*$/", $nama_peg)){
                            $_SESSION['enama_peg'] = 'Form Nama Pegawai hanya boleh mengandung karakter huruf, angka, spasi, titik(.), koma(,), minus(-),kurung() dan garis miring(/)';
                            echo '<script language="javascript">window.history.back();</script>';
                        } else {

                            if(!preg_match("/^[0-9]*$/", $nip)){
                                $_SESSION['enip'] = 'Form NIP hanya boleh mengandung karakter huruf, angka, spasi, titik(.), minus(-) dan garis miring(/)';
                                echo '<script language="javascript">window.history.back();</script>';
                            } else {

                                if(!preg_match("/^[a-zA-Z0-9.,() \/ -]*$/", $pangkat)){
                                    $_SESSION['epangkat'] = 'Form Pangkat hanya boleh mengandung karakter huruf, angka, spasi, titik(.), koma(,), minus(-), kurung() dan garis miring(/)';
                                    echo '<script language="javascript">window.history.back();</script>';
                                } else {

                                    if(!preg_match("/^[a-zA-Z0-9.,() \/ -]*$/", $jabatan)){
                                        $_SESSION['ejabatan'] = 'Form Jabatan hanya boleh mengandung karakter huruf, angka, spasi, titik(.), koma(,), minus(-), kurung() dan garis miring(/)';
                                        echo '<script language="javascript">window.history.back();</script>';
                                    } else {
                                        if(!preg_match("/^[a-zA-Z0-9., -]*$/", $tujuan_tgs)){
                                          $_SESSION['etujuan_tgs'] = 'Form Tujuan Tugas hanya boleh mengandung karakter huruf, angka, spasi, titik(.) dan koma(,) dan minus (-)';
                                           echo '<script language="javascript">window.history.back();</script>';
                                        } else {
                                          if(!preg_match("/^[0-9.-]*$/", $tgl_mulai)){
                                            $_SESSION['etgl_mulai'] = 'Form Tanggal hanya boleh mengandung angka dan minus(-)';
                                            echo '<script language="javascript">window.history.back();</script>';
                                          } else {
                                               if(!preg_match("/^[0-9.-]*$/", $tgl_selesai)){
                                                $_SESSION['etgl_selesai'] = 'Form Tanggal hanya boleh mengandung angka dan minus(-)';
                                                 echo '<script language="javascript">window.history.back();</script>';
                                              } else {
                                            if(!preg_match("/^[a-zA-Z0-9.,()\/ -]*$/", $beban_ang)){
                                                $_SESSION['ebeban_ang'] = 'Form Beban anggaran hanya boleh mengandung karakter huruf, angka, spasi, titik(.), koma(,), minus(-), garis miring(/), dan kurung()';
                                                echo '<script language="javascript">window.history.back();</script>';
                                            } else {

                                                $ekstensi = array('jpg','png','jpeg','doc','docx','pdf');
                                                $file = $_FILES['file']['name'];
                                                $x = explode('.', $file);
                                                $eks = strtolower(end($x));
                                                $ukuran = $_FILES['file']['size'];
                                                $target_dir = "upload/surat_tugas/";

                                                if (! is_dir($target_dir)) {
                                                    mkdir($target_dir, 0755, true);
                                                }

                                            //jika form file tidak kosong akan mengeksekusi script dibawah ini
                                            if($file != ""){

                                                $rand = rand(1,10000);
                                                $nfile = $rand."-".$file;

                                                //validasi file
                                                if(in_array($eks, $ekstensi) == true){
                                                    if($ukuran < 2300000){

                                                        $id_surat = $_REQUEST['id_surat'];
                                                        $query = mysqli_query($config, "SELECT file FROM tbl_surat_tugas WHERE id_surat='$id_surat'");
                                                        list($file) = mysqli_fetch_array($query);

                                                        //jika file tidak kosong akan mengeksekusi script dibawah ini
                                                        if(!empty($file)){
                                                            unlink($target_dir.$file);

                                                            move_uploaded_file($_FILES['file']['tmp_name'], $target_dir.$nfile);

                                                            $query = mysqli_query($config, "UPDATE tbl_surat_tugas SET no_agenda='$no_agenda',no_surtug='$no_surtug',nosu_lengkap='$nosu_lengkap',nama_peg='$nama_peg',nip='$nip',pangkat='$pangkat',jabatan='$jabatan',tujuan_tgs='$tujuan_tgs',tgl_mulai='$tgl_mulai',tgl_selesai='$tgl_selesai',file='$nfile',beban_ang='$beban_ang',kode='$kode',id_user='$id_user' WHERE id_surat='$id_surat'");

                                                            if($query == true){
                                                                $_SESSION['succEdit'] = 'SUKSES! Data berhasil diupdate';
                                                                header("Location: ./admin.php?page=tst");
                                                                die();
                                                            } else {
                                                                $_SESSION['errQ'] = 'ERROR! Ada masalah dengan query';
                                                                echo '<script language="javascript">window.history.back();</script>';
                                                            }
                                                        } else {

                                                            //jika file kosong akan mengeksekusi script dibawah ini
                                                            move_uploaded_file($_FILES['file']['tmp_name'], $target_dir.$nfile);

                                                            $query = mysqli_query($config, "UPDATE tbl_surat_tugas SET no_agenda='$no_agenda',no_surtug='$no_surtug',nosu_lengkap='$nosu_lengkap',nama_peg='$nama_peg',nip='$nip',pangkat='$pangkat',jabatan='$jabatan',tujuan_tgs='$tujuan_tgs',tgl_mulai='$tgl_mulai',tgl_selesai='$tgl_selesai',file='$nfile',beban_ang='$beban_ang',kode='$kode',id_user='$id_user' WHERE id_surat='$id_surat'");

                                                            if($query == true){
                                                                $_SESSION['succEdit'] = 'SUKSES! Data berhasil diupdate';
                                                                header("Location: ./admin.php?page=tst");
                                                                die();
                                                            } else {
                                                                $_SESSION['errQ'] = 'ERROR! Ada masalah dengan query';
                                                                echo '<script language="javascript">window.history.back();</script>';
                                                            }
                                                        }
                                                    } else {
                                                        $_SESSION['errSize'] = 'Ukuran file yang diupload terlalu besar!';
                                                        echo '<script language="javascript">window.history.back();</script>';
                                                    }
                                                } else {
                                                    $_SESSION['errFormat'] = 'Format file yang diperbolehkan hanya *.JPG, *.PNG, *.DOC, *.DOCX atau *.PDF!';
                                                    echo '<script language="javascript">window.history.back();</script>';
                                                }
                                            } else {

                                                //jika form file kosong akan mengeksekusi script dibawah ini
                                                $id_surat = $_REQUEST['id_surat'];

                                                $query = mysqli_query($config, "UPDATE tbl_surat_tugas SET no_agenda='$no_agenda',no_surtug='$no_surtug',nosu_lengkap='$nosu_lengkap',nama_peg='$nama_peg',nip='$nip',pangkat='$pangkat',jabatan='$jabatan',tujuan_tgs='$tujuan_tgs',tgl_mulai='$tgl_mulai',tgl_selesai='$tgl_selesai',beban_ang='$beban_ang',kode='$kode',id_user='$id_user' WHERE id_surat='$id_surat'");

                                                if($query == true){
                                                    $_SESSION['succEdit'] = 'SUKSES! Data berhasil diupdate';
                                                    header("Location: ./admin.php?page=tst");
                                                    die();
                                                } else {
                                                    $_SESSION['errQ'] = 'ERROR! Ada masalah dengan query';
                                                    echo '<script language="javascript">window.history.back();</script>';
                                                }
                                            }
                                           }
                                          }
                                         } 

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {

        $id_surat = mysqli_real_escape_string($config, $_REQUEST['id_surat']);
        $query = mysqli_query($config, "SELECT id_surat, no_agenda, no_surtug, nosu_lengkap,nama_peg, nip, pangkat, jabatan, tujuan_tgs,tgl_mulai,tgl_selesai, file, beban_ang, kode, id_user FROM tbl_surat_tugas WHERE id_surat='$id_surat'");
        list($id_surat, $no_agenda, $no_surtug, $nosu_lengkap, $nama_peg, $nip, $pangkat, $jabatan, $tujuan_tgs, $tgl_mulai, $tgl_selesai, $file, $beban_ang, $kode,$id_user) = mysqli_fetch_array($query);

        if($_SESSION['id_user'] != $id_user AND $_SESSION['id_user'] > 2){
            echo '<script language="javascript">
                    window.alert("ERROR! Anda tidak memiliki hak akses untuk mengedit data ini");
                    window.location.href="./admin.php?page=tst";
                  </script>';
        } else {?>

            <!-- Row Start -->
            <div class="row">
                <!-- Secondary Nav START -->
                <div class="col s12">
                    <nav class="secondary-nav">
                        <div class="nav-wrapper blue darken-1">
                            <ul class="left">
                                <li class="waves-effect waves-light"><a href="#" class="judul"><i class="material-icons">edit</i> Edit Data Surat Tugas</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
                <!-- Secondary Nav END -->
            </div>
            <!-- Row END -->

            <?php
                if(isset($_SESSION['errQ'])){
                    $errQ = $_SESSION['errQ'];
                    echo '<div id="alert-message" class="row">
                            <div class="col m12">
                                <div class="card red lighten-5">
                                    <div class="card-content notif">
                                        <span class="card-title red-text"><i class="material-icons md-36">clear</i> '.$errQ.'</span>
                                    </div>
                                </div>
                            </div>
                        </div>';
                    unset($_SESSION['errQ']);
                }
                if(isset($_SESSION['errEmpty'])){
                    $errEmpty = $_SESSION['errEmpty'];
                    echo '<div id="alert-message" class="row">
                            <div class="col m12">
                                <div class="card red lighten-5">
                                    <div class="card-content notif">
                                        <span class="card-title red-text"><i class="material-icons md-36">clear</i> '.$errEmpty.'</span>
                                    </div>
                                </div>
                            </div>
                        </div>';
                    unset($_SESSION['errEmpty']);
                }
            ?>

            <!-- Row form Start -->
            <div class="row jarak-form">

                <!-- Form START -->
                <form class="col s12" method="POST" action="?page=tst&act=edit" enctype="multipart/form-data">

                    <!-- Row in form START -->
                    <div class="row">
                        <div class="input-field col s6">
                            <input type="hidden" name="id_surat" value="<?php echo $id_surat ;?>">
                            <i class="material-icons prefix md-prefix">looks_one</i>
                            <input id="no_agenda" type="number" class="validate" value="<?php echo $no_agenda ;?>" name="no_agenda"  readonly required>
                                <?php
                                    if(isset($_SESSION['eno_agenda'])){
                                        $eno_agenda = $_SESSION['eno_agenda'];
                                        echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$eno_agenda.'</div>';
                                        unset($_SESSION['eno_agenda']);
                                    }
                                ?>
                            <label for="no_agenda">Nomor Agenda</label>
                        </div>

                        <div class="input-field col s6">
                            <i class="material-icons prefix md-prefix">looks_two</i>
                            <input id="kode" type="text" class="validate" name="kode" value="<?php echo $kode ;?>" required>
                                <?php
                                    if(isset($_SESSION['ekode'])){
                                        $ekode = $_SESSION['ekode'];
                                        echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$ekode.'</div>';
                                        unset($_SESSION['ekode']);
                                    }
                                ?>
                            <label for="kode">Kode Klasifikasi</label>
                        </div>

                        <div class="input-field col s6">
                            <i class="material-icons prefix md-prefix">storage</i>
                            <div class="input-field col s11 right">
                                <select name="nama_peg" id="nama_peg" type="text" class="browser-default validate" onchange='changeValue(this.value)' readonly>
                           
                                 

                                 <option value="<?php echo $nama_peg;?>"><?php echo $nama_peg;?></option>
                                 <?php 
                                 $query=mysqli_query($config, "select * from tbl_pegawai order by nama_peg asc"); 
                                 $result = mysqli_query($config, "select * from tbl_pegawai order by nama_peg asc");  
                                 $jsArray = "var prdName = new Array();\n";
                                 while ($row = mysqli_fetch_array($result)) {  
                                  

                                 echo '<option name="nama_peg"  value="' . $row['nama_peg'] . '">' . $row['nama_peg'] . '</option>';  
                                 $jsArray .= "prdName['" . $row['nama_peg'] . "'] = {nip:'" . addslashes($row['nip']) . "',pangkat:'".addslashes($row['pangkat'])."',jabatan:'".addslashes($row['jabatan'])."'};\n";
                                  }
                                 
                                  ?>
                                </select>

                                <input id="nip" type="text" class="validate" name="nip" value="<?php echo $nip ;?>" readonly >
                                <input id="pangkat" type="text" class="validate" name="pangkat" value="<?php echo $pangkat;?>" readonly >
                                <input id="jabatan" type="text" class="validate" name="jabatan" value="<?php echo $jabatan;?>" readonly >
                            </div>    
                            <label for="nama_peg">Nama Pegawai</label>
                        </div>

                        
                        <div class="input-field col s6">
                            <i class="material-icons prefix md-prefix">description</i>
                            <input id="no_surtug" type="text" class="validate" name="no_surtug" value="<?php echo $no_surtug ;?>"  readonly required>
                                <?php
                                    if(isset($_SESSION['eno_surtug'])){
                                        $eno_surtug = $_SESSION['eano_surtug'];
                                        echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$eno_surtug.'</div>';
                                        unset($_SESSION['eno_surtug']);
                                    }
                                ?>
                            <label for="no_surtug">Nomor Surat</label>
                        </div>
                       
                        <div class="input-field col s6">
                            <i class="material-icons prefix md-prefix">description</i>
                            <input id="tujuan_tgs" type="text" class="validate" name="tujuan_tgs" value="<?php echo $tujuan_tgs ;?>" required>
                                <?php
                                    if(isset($_SESSION['etujuan_tgs'])){
                                        $eketerangan = $_SESSION['etujuan_tgs'];
                                        echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$etujuan_tgs.'</div>';
                                        unset($_SESSION['etujuan_tgs']);
                                    }
                                ?>
                            <label for="tujuan_tgs">Tujuan Tugas</label>
                        </div>

                        <div class="input-field col s6">
                            <i class="material-icons prefix md-prefix">date_range</i>
                            <input id="tgl_mulai" type="text" name="tgl_mulai" class="datepicker" value="<?php echo $tgl_mulai ;?>" required>
                                <?php
                                    if(isset($_SESSION['etgl_mulai'])){
                                        $etgl_mulai = $_SESSION['etgl_mulai'];
                                        echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$etgl_mulai.'</div>';
                                        unset($_SESSION['etgl_mulai']);
                                    }
                                ?>
                            <label for="tgl_mulai">Tanggal Mulai</label>
                        </div>

                        <div class="input-field col s6">
                            <i class="material-icons prefix md-prefix">date_range</i>
                            <input id="tgl_selesai" type="text" name="tgl_selesai" class="datepicker" value="<?php echo $tgl_selesai ;?>" required>
                                <?php
                                    if(isset($_SESSION['etgl_selesai'])){
                                        $etgl_selesai = $_SESSION['etgl_selesai'];
                                        echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$etgl_selesai.'</div>';
                                        unset($_SESSION['etgl_selesai']);
                                    }
                                ?>
                            <label for="tgl_selesai">Tanggal Selesai</label>
                        </div>

                        <div class="input-field col s6">
                            <i class="material-icons prefix md-prefix">description</i>
                            <input id="beban_ang" type="text" name="beban_ang" value="<?php echo $beban_ang ;?>" required>
                                <?php
                                    if(isset($_SESSION['ebeban_ang'])){
                                        $ebeban_ang = $_SESSION['ebeban_ang'];
                                        echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$ebeban_ang.'</div>';
                                        unset($_SESSION['ebeban_ang']);
                                    }
                                ?>
                            <label for="beban_ang">Pembebanan</label>
                        </div>    

                        <div class="input-field col s6">
                            <div class="file-field input-field">
                                <div class="btn light-green darken-1">
                                    <span>File</span>
                                    <input type="file" id="file" name="file">
                                </div>
                                <div class="file-path-wrapper">
                                    <input class="file-path validate" type="text" value="<?php echo $file ;?>" placeholder="Upload file/scan gambar surat tugas">
                                        <?php
                                            if(isset($_SESSION['errSize'])){
                                                $errSize = $_SESSION['errSize'];
                                                echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$errSize.'</div>';
                                                unset($_SESSION['errSize']);
                                            }
                                            if(isset($_SESSION['errFormat'])){
                                                $errFormat = $_SESSION['errFormat'];
                                                echo '<div id="alert-message" class="callout bottom z-depth-1 red lighten-4 red-text">'.$errFormat.'</div>';
                                                unset($_SESSION['errFormat']);
                                            }
                                        ?>
                                    <small class="red-text">*Format file yang diperbolehkan *.JPG, *.PNG, *.DOC, *.DOCX, *.PDF dan ukuran maksimal file 2 MB!</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Row in form END -->

                    <div class="row">
                        <div class="col 6">
                            <button type="submit" name="submit" class="btn-large blue waves-effect waves-light">SIMPAN <i class="material-icons">done</i></button>
                        </div>
                        <div class="col 6">
                            <a href="?page=tst" class="btn-large deep-orange waves-effect waves-light">BATAL <i class="material-icons">clear</i></a>
                        </div>
                    </div>

                </form>
                <!-- Form END -->

            </div>
            <!-- Row form END -->

<?php
            }
        }
    }
?>
<script type="text/javascript"> 
<?php echo $jsArray; ?>
function changeValue(id){
    document.getElementById('nip').value = prdName[id].nip;
    document.getElementById('pangkat').value = prdName[id].pangkat;
    document.getElementById('jabatan').value = prdName[id].jabatan;
};
</script>
